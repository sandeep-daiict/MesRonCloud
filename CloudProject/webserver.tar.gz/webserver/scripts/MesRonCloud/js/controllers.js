'use strict';
var scopes ;
/* Controllers */

function Storage($scope, request) 
{

	
}

function CreateStorage($scope, request) 
{}

function DestroyStorage($scope, request) 
{}

function ManageStorage($scope, request) 
{}


function Attach($scope, request) 
{}

function Detach($scope, request) 
{}

function Format($scope, request) 
{}





function ComputeEngineCtrl($scope, request)
{}


function Create($scope, request) 
{}

function Destroy($scope, request) 
{}

function Manage($scope, request) 
{}
function ComputeEngineCtrl($scope, request)
{}

function HomePageCtrl($scope, request) 
{
 /* request.query();
scopes = $scope;
*/	
}


//PhoneListCtrl.$inject = ['$scope', 'Phone'];
 function JSON_CALLBACK( returned_data )
{
	scopes.vms = returned_data.types;
}


function PhoneDetailCtrl($scope, $routeParams, Phone) {
  $scope.phone = Phone.get({phoneId: $routeParams.phoneId}, function(phone) {
    $scope.mainImageUrl = phone.images[0];
  });

  $scope.setImage = function(imageUrl) {
    $scope.mainImageUrl = imageUrl;
  }
}

//PhoneDetailCtrl.$inject = ['$scope', '$routeParams', 'Phone'];
